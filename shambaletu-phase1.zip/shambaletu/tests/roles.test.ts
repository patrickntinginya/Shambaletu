import { describe, it, expect } from "vitest";
import { Role } from "@prisma/client";
import { ROLE_DASHBOARD_PATH, DASHBOARD_PATH_ROLE, REGISTERABLE_ROLES } from "@/lib/roles";

describe("role dashboard mapping", () => {
  it("maps every role to exactly one dashboard path", () => {
    const allRoles = Object.values(Role);
    for (const role of allRoles) {
      expect(ROLE_DASHBOARD_PATH[role]).toBeTruthy();
    }
  });

  it("maps admin to the admin dashboard, not /dashboard/*", () => {
    expect(ROLE_DASHBOARD_PATH[Role.ADMIN]).toBe("/admin/dashboard");
  });

  it("is invertible: path -> role -> same path", () => {
    for (const [role, path] of Object.entries(ROLE_DASHBOARD_PATH)) {
      expect(DASHBOARD_PATH_ROLE[path]).toBe(role);
    }
  });

  it("excludes ADMIN from self-registration options", () => {
    expect(REGISTERABLE_ROLES).not.toContain(Role.ADMIN);
    expect(REGISTERABLE_ROLES.length).toBe(Object.values(Role).length - 1);
  });
});
