import { describe, it, expect } from "vitest";
import { hashPassword, verifyPassword } from "@/lib/password";

describe("password hashing", () => {
  it("hashes a password to a bcrypt string, not plain text", async () => {
    const hash = await hashPassword("Password123!");
    expect(hash).not.toBe("Password123!");
    expect(hash.startsWith("$2")).toBe(true);
  });

  it("verifies a correct password against its hash", async () => {
    const hash = await hashPassword("Password123!");
    const isValid = await verifyPassword("Password123!", hash);
    expect(isValid).toBe(true);
  });

  it("rejects an incorrect password", async () => {
    const hash = await hashPassword("Password123!");
    const isValid = await verifyPassword("WrongPassword!", hash);
    expect(isValid).toBe(false);
  });
});
