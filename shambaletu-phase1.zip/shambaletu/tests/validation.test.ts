import { describe, it, expect } from "vitest";
import { registerSchema, loginSchema } from "@/lib/validation";
import { Role } from "@prisma/client";

const validRegisterPayload = {
  name: "Juma Mwakalinga",
  email: "juma@mfano.com",
  phone: "0712345678",
  password: "Password123",
  confirmPassword: "Password123",
  role: Role.FARMER,
  region: "Morogoro",
  district: "Kilosa",
  ward: "Mikumi",
};

describe("registerSchema", () => {
  it("accepts a valid registration payload", () => {
    const result = registerSchema.safeParse(validRegisterPayload);
    expect(result.success).toBe(true);
  });

  it("rejects mismatched passwords", () => {
    const result = registerSchema.safeParse({
      ...validRegisterPayload,
      confirmPassword: "Different123",
    });
    expect(result.success).toBe(false);
  });

  it("rejects an invalid Tanzanian phone number", () => {
    const result = registerSchema.safeParse({
      ...validRegisterPayload,
      phone: "12345",
    });
    expect(result.success).toBe(false);
  });

  it("rejects registering directly as ADMIN", () => {
    const result = registerSchema.safeParse({
      ...validRegisterPayload,
      role: Role.ADMIN,
    });
    expect(result.success).toBe(false);
  });

  it("rejects a weak password with no uppercase or number", () => {
    const result = registerSchema.safeParse({
      ...validRegisterPayload,
      password: "weakpassword",
      confirmPassword: "weakpassword",
    });
    expect(result.success).toBe(false);
  });
});

describe("loginSchema", () => {
  it("accepts a valid login payload", () => {
    const result = loginSchema.safeParse({
      email: "juma@mfano.com",
      password: "anything",
    });
    expect(result.success).toBe(true);
  });

  it("rejects an invalid email", () => {
    const result = loginSchema.safeParse({
      email: "not-an-email",
      password: "anything",
    });
    expect(result.success).toBe(false);
  });
});
