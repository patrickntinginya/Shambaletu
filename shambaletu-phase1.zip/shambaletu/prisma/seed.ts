/**
 * ShambaLetu - Development seed data
 *
 * Creates one demo account per role so every dashboard can be exercised
 * immediately after setup. Run with: npm run seed
 *
 * All demo accounts use the password: Password123!
 */
import { PrismaClient, Role } from "@prisma/client";
import bcrypt from "bcryptjs";

const prisma = new PrismaClient();

const DEMO_PASSWORD = "Password123!";

async function hash(password: string) {
  return bcrypt.hash(password, 12);
}

async function main() {
  const passwordHash = await hash(DEMO_PASSWORD);

  const demoUsers: Array<{
    name: string;
    email: string;
    phone: string;
    role: Role;
    region: string;
    district: string;
    ward: string;
    bio: string;
  }> = [
    {
      name: "Juma Mwakalinga",
      email: "farmer@shambaletu.co.tz",
      phone: "+255700000001",
      role: Role.FARMER,
      region: "Morogoro",
      district: "Kilosa",
      ward: "Mikumi",
      bio: "Mkulima wa mahindi na mpunga.",
    },
    {
      name: "Neema Kway",
      email: "livestock@shambaletu.co.tz",
      phone: "+255700000002",
      role: Role.LIVESTOCK_KEEPER,
      region: "Arusha",
      district: "Monduli",
      ward: "Engaruka",
      bio: "Mfugaji wa ng'ombe na mbuzi.",
    },
    {
      name: "Amina Buyer",
      email: "buyer@shambaletu.co.tz",
      phone: "+255700000003",
      role: Role.BUYER,
      region: "Dar es Salaam",
      district: "Ilala",
      ward: "Upanga",
      bio: "Ninanunua mazao kwa jumla kwa ajili ya soko.",
    },
    {
      name: "Kilimo Biashara Ltd",
      email: "business@shambaletu.co.tz",
      phone: "+255700000004",
      role: Role.AGRICULTURAL_BUSINESS,
      region: "Dodoma",
      district: "Dodoma Mjini",
      ward: "Area C",
      bio: "Kampuni ya usambazaji wa pembejeo za kilimo.",
    },
    {
      name: "Haraka Transport",
      email: "transporter@shambaletu.co.tz",
      phone: "+255700000005",
      role: Role.TRANSPORTER,
      region: "Mbeya",
      district: "Mbeya Mjini",
      ward: "Ilomba",
      bio: "Huduma za usafirishaji wa mazao na mifugo.",
    },
    {
      name: "Dr. Elvis Mifugo",
      email: "vet@shambaletu.co.tz",
      phone: "+255700000006",
      role: Role.SERVICE_PROVIDER,
      region: "Iringa",
      district: "Iringa Vijijini",
      ward: "Kalenga",
      bio: "Daktari wa mifugo - huduma za chanjo na matibabu.",
    },
    {
      name: "Admin ShambaLetu",
      email: "admin@shambaletu.co.tz",
      phone: "+255700000000",
      role: Role.ADMIN,
      region: "Dar es Salaam",
      district: "Kinondoni",
      ward: "Mikocheni",
      bio: "Msimamizi wa mfumo.",
    },
  ];

  for (const u of demoUsers) {
    const user = await prisma.user.upsert({
      where: { email: u.email },
      update: {},
      create: {
        name: u.name,
        email: u.email,
        phone: u.phone,
        passwordHash,
        role: u.role,
        profile: {
          create: {
            fullName: u.name,
            phone: u.phone,
            region: u.region,
            district: u.district,
            ward: u.ward,
            bio: u.bio,
          },
        },
      },
    });

    if (u.role === Role.FARMER) {
      await prisma.farm.upsert({
        where: { id: `${user.id}-seed-farm` },
        update: {},
        create: {
          id: `${user.id}-seed-farm`,
          ownerId: user.id,
          farmName: "Shamba la Mfano",
          region: u.region,
          district: u.district,
          ward: u.ward,
          approximateLocation: `${u.district}, ${u.region}`,
          farmSize: 5,
          farmSizeUnit: "acre",
          description: "Shamba la mfano kwa ajili ya majaribio ya mfumo.",
        },
      });
    }

    if (u.role === Role.LIVESTOCK_KEEPER) {
      await prisma.livestockProfile.upsert({
        where: { id: `${user.id}-seed-livestock` },
        update: {},
        create: {
          id: `${user.id}-seed-livestock`,
          ownerId: user.id,
          livestockType: "Ng'ombe wa maziwa",
          quantity: 12,
          region: u.region,
          district: u.district,
          description: "Kundi la mfano la ng'ombe wa maziwa.",
        },
      });
    }
  }

  console.log("Seed complete. Demo accounts (password for all: %s):", DEMO_PASSWORD);
  demoUsers.forEach((u) => console.log(`  - [${u.role}] ${u.email}`));
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
