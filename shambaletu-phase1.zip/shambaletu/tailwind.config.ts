import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./src/app/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/components/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        // ShambaLetu brand palette: earthy green (growth/agriculture)
        // with a warm harvest gold accent.
        brand: {
          50: "#f1f9ee",
          100: "#dff0d8",
          200: "#bfe0b3",
          300: "#96cb85",
          400: "#6cb257",
          500: "#4a9636", // primary
          600: "#38792a",
          700: "#2c5f22",
          800: "#244c1d",
          900: "#1e3f19",
        },
        harvest: {
          100: "#fbf0d9",
          400: "#f2c14e",
          500: "#e8a838", // accent
          600: "#c98c25",
        },
        earth: {
          50: "#faf8f5",
          100: "#f0ebe3",
          800: "#4a3f33",
          900: "#2c2620",
        },
      },
      fontFamily: {
        sans: [
          "-apple-system",
          "BlinkMacSystemFont",
          "Segoe UI",
          "Roboto",
          "Helvetica Neue",
          "Arial",
          "sans-serif",
        ],
      },
      borderRadius: {
        xl2: "1rem",
      },
    },
  },
  plugins: [],
};

export default config;
