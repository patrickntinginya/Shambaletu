import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/current-user";
import { ROLE_DASHBOARD_PATH } from "@/lib/roles";

export default async function DashboardIndexPage() {
  const user = await getCurrentUser();
  if (!user) {
    redirect("/login");
  }
  redirect(ROLE_DASHBOARD_PATH[user.role]);
}
