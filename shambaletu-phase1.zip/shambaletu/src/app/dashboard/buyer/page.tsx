import { requireRole } from "@/lib/require-role";
import { Role } from "@/lib/roles";
import DashboardShell from "@/components/layout/DashboardShell";
import ProfileSummaryCard from "@/components/dashboard/ProfileSummaryCard";
import { PlaceholderCard } from "@/components/ui/Card";

export default async function BuyerDashboardPage() {
  const user = await requireRole(Role.BUYER);

  return (
    <DashboardShell
      userName={user.name}
      role={user.role}
      navItems={[
        { label: "Dashibodi", available: true },
        { label: "Wasifu", available: true },
        { label: "Vipendwa", available: false },
        { label: "Oda Zangu", available: false },
        { label: "Ujumbe", available: false },
        { label: "Mapendekezo", available: false },
        { label: "Nina Hitaji", available: false },
      ]}
    >
      <h1 className="text-xl font-bold text-earth-900">Dashibodi ya Mnunuzi</h1>
      <p className="mt-1 text-sm text-earth-800/70">
        Karibu, {user.name}. Hii ni sehemu yako ya kutafuta mazao na mifugo ShambaLetu.
      </p>

      <div className="mt-6 grid grid-cols-1 gap-4 lg:grid-cols-2">
        <ProfileSummaryCard
          fullName={user.profile?.fullName ?? user.name}
          email={user.email}
          phone={user.profile?.phone ?? user.phone}
          region={user.profile?.region ?? null}
          district={user.profile?.district ?? null}
          ward={user.profile?.ward ?? null}
          bio={user.profile?.bio ?? null}
        />
        <PlaceholderCard
          title="Tafuta Bidhaa"
          description="Soko la kutafuta mazao/mifugo kwa kategoria, mkoa na bei. Inakuja Phase 2."
        />
        <PlaceholderCard
          title="Nina Hitaji"
          description="Chapisha mahitaji yako (kiasi, bei ya juu, tarehe) na upate kulinganishwa na wauzaji. Inakuja baadaye."
        />
        <PlaceholderCard
          title="Vipendwa"
          description="Bidhaa ulizohifadhi kwa ajili ya baadaye. Inakuja Phase 2."
        />
        <PlaceholderCard
          title="Oda Zangu"
          description="Historia ya maombi na oda zako. Inakuja Phase 2+."
        />
        <PlaceholderCard
          title="Ujumbe"
          description="Mazungumzo yako na wauzaji. Inakuja Phase 2+."
        />
      </div>
    </DashboardShell>
  );
}
