import { requireRole } from "@/lib/require-role";
import { Role } from "@/lib/roles";
import DashboardShell from "@/components/layout/DashboardShell";
import ProfileSummaryCard from "@/components/dashboard/ProfileSummaryCard";
import { PlaceholderCard } from "@/components/ui/Card";

export default async function LivestockDashboardPage() {
  const user = await requireRole(Role.LIVESTOCK_KEEPER);

  return (
    <DashboardShell
      userName={user.name}
      role={user.role}
      navItems={[
        { label: "Dashibodi", available: true },
        { label: "Wasifu", available: true },
        { label: "Mifugo Yangu", available: false },
        { label: "Ongeza Mfugo", available: false },
        { label: "Maombi/Oda", available: false },
        { label: "Ujumbe", available: false },
        { label: "Arifa", available: false },
      ]}
    >
      <h1 className="text-xl font-bold text-earth-900">Dashibodi ya Mfugaji</h1>
      <p className="mt-1 text-sm text-earth-800/70">
        Karibu, {user.name}. Hii ni sehemu yako ya kusimamia mifugo yako ShambaLetu.
      </p>

      <div className="mt-6 grid grid-cols-1 gap-4 lg:grid-cols-2">
        <ProfileSummaryCard
          fullName={user.profile?.fullName ?? user.name}
          email={user.email}
          phone={user.profile?.phone ?? user.phone}
          region={user.profile?.region ?? null}
          district={user.profile?.district ?? null}
          ward={user.profile?.ward ?? null}
          bio={user.profile?.bio ?? null}
        />
        <PlaceholderCard
          title="Mifugo Yangu"
          description="Orodha ya mifugo uliyotangaza itaonekana hapa. Inakuja Phase 2."
        />
        <PlaceholderCard
          title="Ongeza Mfugo Mpya"
          description="Fomu ya kutangaza mifugo mipya na picha, bei, na idadi. Inakuja Phase 2."
        />
        <PlaceholderCard
          title="Maombi na Oda"
          description="Maombi ya ununuzi kutoka kwa wanunuzi yataonekana hapa. Inakuja Phase 2+."
        />
        <PlaceholderCard
          title="Ujumbe"
          description="Mazungumzo na wanunuzi kuhusu mifugo yako. Inakuja Phase 2+."
        />
      </div>
    </DashboardShell>
  );
}
