import { requireRole } from "@/lib/require-role";
import { Role } from "@/lib/roles";
import DashboardShell from "@/components/layout/DashboardShell";
import ProfileSummaryCard from "@/components/dashboard/ProfileSummaryCard";
import { PlaceholderCard } from "@/components/ui/Card";

export default async function FarmerDashboardPage() {
  const user = await requireRole(Role.FARMER);

  return (
    <DashboardShell
      userName={user.name}
      role={user.role}
      navItems={[
        { label: "Dashibodi", available: true },
        { label: "Wasifu", available: true },
        { label: "Mazao Yangu", available: false },
        { label: "Ongeza Bidhaa", available: false },
        { label: "Maombi/Oda", available: false },
        { label: "Ujumbe", available: false },
        { label: "Vipendwa", available: false },
        { label: "Arifa", available: false },
      ]}
    >
      <h1 className="text-xl font-bold text-earth-900">Dashibodi ya Mkulima</h1>
      <p className="mt-1 text-sm text-earth-800/70">
        Karibu, {user.name}. Hii ni sehemu yako ya kusimamia mazao yako ShambaLetu.
      </p>

      <div className="mt-6 grid grid-cols-1 gap-4 lg:grid-cols-2">
        <ProfileSummaryCard
          fullName={user.profile?.fullName ?? user.name}
          email={user.email}
          phone={user.profile?.phone ?? user.phone}
          region={user.profile?.region ?? null}
          district={user.profile?.district ?? null}
          ward={user.profile?.ward ?? null}
          bio={user.profile?.bio ?? null}
        />
        <PlaceholderCard
          title="Mazao Yangu"
          description="Orodha ya mazao/bidhaa ulizochapisha itaonekana hapa. Inakuja Phase 2."
        />
        <PlaceholderCard
          title="Ongeza Bidhaa Mpya"
          description="Fomu ya kuchapisha mazao/mifugo mipya na picha, bei, na kiasi. Inakuja Phase 2."
        />
        <PlaceholderCard
          title="Maombi na Oda"
          description="Maombi ya ununuzi kutoka kwa wanunuzi yataonekana hapa. Inakuja Phase 2+."
        />
        <PlaceholderCard
          title="Ujumbe"
          description="Mazungumzo na wanunuzi kuhusu bidhaa zako. Inakuja Phase 2+."
        />
        <PlaceholderCard
          title="Arifa"
          description="Arifa za akaunti yako na shughuli za soko. Inakuja Phase 2+."
        />
      </div>
    </DashboardShell>
  );
}
