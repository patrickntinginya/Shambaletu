import { requireRole } from "@/lib/require-role";
import { Role } from "@/lib/roles";
import DashboardShell from "@/components/layout/DashboardShell";
import ProfileSummaryCard from "@/components/dashboard/ProfileSummaryCard";
import { PlaceholderCard } from "@/components/ui/Card";

export default async function BusinessDashboardPage() {
  const user = await requireRole(Role.AGRICULTURAL_BUSINESS);

  return (
    <DashboardShell
      userName={user.name}
      role={user.role}
      navItems={[
        { label: "Dashibodi", available: true },
        { label: "Wasifu", available: true },
        { label: "Bidhaa Zangu", available: false },
        { label: "Maombi/Oda", available: false },
        { label: "Ujumbe", available: false },
        { label: "Uthibitisho", available: false },
      ]}
    >
      <h1 className="text-xl font-bold text-earth-900">Dashibodi ya Biashara ya Kilimo</h1>
      <p className="mt-1 text-sm text-earth-800/70">
        Karibu, {user.name}. Hii ni sehemu yako ya kusimamia biashara yako ShambaLetu.
      </p>

      <div className="mt-6 grid grid-cols-1 gap-4 lg:grid-cols-2">
        <ProfileSummaryCard
          fullName={user.profile?.fullName ?? user.name}
          email={user.email}
          phone={user.profile?.phone ?? user.phone}
          region={user.profile?.region ?? null}
          district={user.profile?.district ?? null}
          ward={user.profile?.ward ?? null}
          bio={user.profile?.bio ?? null}
        />
        <PlaceholderCard
          title="Bidhaa/Pembejeo Zangu"
          description="Orodha ya pembejeo za kilimo unazouza (mbolea, mbegu, zana). Inakuja Phase 2."
        />
        <PlaceholderCard
          title="Uthibitisho wa Biashara"
          description="Pakia hati za biashara kupata alama ya uthibitisho. Inakuja baadaye."
        />
        <PlaceholderCard
          title="Maombi na Oda"
          description="Maombi kutoka kwa wakulima na wafugaji. Inakuja Phase 2+."
        />
      </div>
    </DashboardShell>
  );
}
