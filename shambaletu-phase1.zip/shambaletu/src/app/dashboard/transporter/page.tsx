import { requireRole } from "@/lib/require-role";
import { Role } from "@/lib/roles";
import DashboardShell from "@/components/layout/DashboardShell";
import ProfileSummaryCard from "@/components/dashboard/ProfileSummaryCard";
import { PlaceholderCard } from "@/components/ui/Card";

export default async function TransporterDashboardPage() {
  const user = await requireRole(Role.TRANSPORTER);

  return (
    <DashboardShell
      userName={user.name}
      role={user.role}
      navItems={[
        { label: "Dashibodi", available: true },
        { label: "Wasifu", available: true },
        { label: "Maombi ya Usafirishaji", available: false },
        { label: "Njia Zangu", available: false },
        { label: "Ujumbe", available: false },
      ]}
    >
      <h1 className="text-xl font-bold text-earth-900">Dashibodi ya Msafirishaji</h1>
      <p className="mt-1 text-sm text-earth-800/70">
        Karibu, {user.name}. Hii ni sehemu yako ya huduma za usafirishaji ShambaLetu.
      </p>

      <div className="mt-6 grid grid-cols-1 gap-4 lg:grid-cols-2">
        <ProfileSummaryCard
          fullName={user.profile?.fullName ?? user.name}
          email={user.email}
          phone={user.profile?.phone ?? user.phone}
          region={user.profile?.region ?? null}
          district={user.profile?.district ?? null}
          ward={user.profile?.ward ?? null}
          bio={user.profile?.bio ?? null}
        />
        <PlaceholderCard
          title="Maombi ya Usafirishaji"
          description="Maombi ya kusafirisha mazao/mifugo kutoka kwa wakulima na wanunuzi. Inakuja Phase 2+."
        />
        <PlaceholderCard
          title="Njia na Uwezo Wangu"
          description="Eleza njia unazohudumia na uwezo wa gari lako. Inakuja baadaye."
        />
      </div>
    </DashboardShell>
  );
}
