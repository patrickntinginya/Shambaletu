import Link from "next/link";
import Navbar from "@/components/layout/Navbar";
import Footer from "@/components/layout/Footer";
import { ROLE_LABELS_SW } from "@/lib/roles";
import { Role } from "@prisma/client";

const roleCards: { role: Role; description: string }[] = [
  { role: Role.FARMER, description: "Uza mazao yako moja kwa moja kwa wanunuzi." },
  { role: Role.LIVESTOCK_KEEPER, description: "Tangaza mifugo yako kwa urahisi." },
  { role: Role.BUYER, description: "Pata mazao na mifugo bora karibu na wewe." },
  { role: Role.AGRICULTURAL_BUSINESS, description: "Fikia wakulima na wafugaji wengi zaidi." },
  { role: Role.TRANSPORTER, description: "Toa huduma za usafirishaji wa mazao." },
  { role: Role.SERVICE_PROVIDER, description: "Toa huduma za kitaalamu za kilimo na mifugo." },
];

export default function HomePage() {
  return (
    <div className="flex min-h-screen flex-col">
      <Navbar />
      <main className="flex-1">
        <section className="mx-auto max-w-6xl px-4 py-14 text-center sm:px-6 sm:py-20">
          <h1 className="text-3xl font-extrabold tracking-tight text-earth-900 sm:text-5xl">
            Karibu <span className="text-brand-600">ShambaLetu</span>
          </h1>
          <p className="mx-auto mt-4 max-w-xl text-lg font-medium italic text-earth-800/70">
            Kilimo chetu. Soko letu. Fursa zetu.
          </p>
          <p className="mx-auto mt-6 max-w-2xl text-base text-earth-800/80">
            Jukwaa linalounganisha wakulima, wafugaji, wanunuzi, biashara za kilimo,
            wasafirishaji na watoa huduma za kilimo - mahali pamoja, kidijitali.
          </p>
          <div className="mt-8 flex flex-col items-center justify-center gap-3 sm:flex-row">
            <Link
              href="/register"
              className="w-full rounded-xl2 bg-brand-600 px-6 py-3.5 text-base font-semibold text-white hover:bg-brand-700 sm:w-auto"
            >
              Anza Sasa - Jisajili
            </Link>
            <Link
              href="/login"
              className="w-full rounded-xl2 border-2 border-brand-600 px-6 py-3.5 text-base font-semibold text-brand-700 hover:bg-brand-50 sm:w-auto"
            >
              Nina Akaunti - Ingia
            </Link>
          </div>
        </section>

        <section className="border-t border-earth-100 bg-earth-50/50 py-14">
          <div className="mx-auto max-w-6xl px-4 sm:px-6">
            <h2 className="text-center text-2xl font-bold text-earth-900">
              Jukwaa kwa kila mdau wa kilimo
            </h2>
            <div className="mt-8 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {roleCards.map((card) => (
                <div
                  key={card.role}
                  className="rounded-xl2 border border-earth-100 bg-white p-5 shadow-sm"
                >
                  <p className="font-semibold text-brand-700">{ROLE_LABELS_SW[card.role]}</p>
                  <p className="mt-2 text-sm text-earth-800/70">{card.description}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section className="mx-auto max-w-3xl px-4 py-14 text-center sm:px-6">
          <h2 className="text-xl font-bold text-earth-900">Hatua ya Kwanza (Phase 1)</h2>
          <p className="mt-3 text-sm text-earth-800/70">
            Kwa sasa unaweza kujisajili, kuingia, na kuona dashibodi yako kulingana na aina
            ya mtumiaji wako. Soko la bidhaa, ujumbe kati ya mnunuzi na muuzaji, na maombi
            ya mahitaji (&quot;Nina Hitaji&quot;) yanakuja katika awamu zijazo.
          </p>
        </section>
      </main>
      <Footer />
    </div>
  );
}
