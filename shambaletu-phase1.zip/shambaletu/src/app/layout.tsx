import type { Metadata, Viewport } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "ShambaLetu - Kilimo chetu. Soko letu. Fursa zetu.",
  description:
    "ShambaLetu ni jukwaa la kidijitali linalounganisha wakulima, wafugaji, wanunuzi, biashara za kilimo, wasafirishaji na watoa huduma za kilimo Tanzania.",
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  themeColor: "#4a9636",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="sw">
      <body className="bg-white font-sans text-earth-900 antialiased">{children}</body>
    </html>
  );
}
