"use client";

import { useState, FormEvent, Suspense } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import Link from "next/link";
import Input from "@/components/ui/Input";
import Button from "@/components/ui/Button";
import Alert from "@/components/ui/Alert";

function LoginForm() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const nextPath = searchParams.get("next") || "/dashboard";

  const [isLoading, setIsLoading] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);
  const [fieldErrors, setFieldErrors] = useState<Record<string, string[] | undefined>>({});

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setFormError(null);
    setFieldErrors({});
    setIsLoading(true);

    const formData = new FormData(event.currentTarget);
    const payload = Object.fromEntries(formData.entries());

    try {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      const data = await res.json();

      if (!res.ok) {
        setFormError(data.error || "Imeshindwa kuingia. Jaribu tena.");
        setFieldErrors(data.fieldErrors || {});
        return;
      }

      router.push(nextPath);
      router.refresh();
    } catch {
      setFormError("Hitilafu ya mtandao. Jaribu tena.");
    } finally {
      setIsLoading(false);
    }
  }

  return (
    <div className="mx-auto flex min-h-screen max-w-md flex-col justify-center px-4 py-10">
      <div className="mb-6 text-center">
        <Link href="/" className="text-xl font-bold text-brand-700">
          ShambaLetu
        </Link>
        <h1 className="mt-3 text-2xl font-bold text-earth-900">Karibu Tena</h1>
        <p className="mt-1 text-sm text-earth-800/70">Ingia kwenye akaunti yako</p>
      </div>

      {formError && (
        <div className="mb-4">
          <Alert variant="error">{formError}</Alert>
        </div>
      )}

      <form onSubmit={handleSubmit} className="flex flex-col gap-4" noValidate>
        <Input
          name="email"
          type="email"
          label="Barua Pepe"
          placeholder="wewe@mfano.com"
          required
          error={fieldErrors.email?.[0]}
        />
        <Input
          name="password"
          type="password"
          label="Nenosiri"
          required
          error={fieldErrors.password?.[0]}
        />
        <Button type="submit" isLoading={isLoading} fullWidth size="lg" className="mt-2">
          Ingia
        </Button>
      </form>

      <p className="mt-6 text-center text-sm text-earth-800/70">
        Huna akaunti?{" "}
        <Link href="/register" className="font-semibold text-brand-700 hover:underline">
          Jisajili hapa
        </Link>
      </p>
    </div>
  );
}

export default function LoginPage() {
  return (
    <Suspense fallback={null}>
      <LoginForm />
    </Suspense>
  );
}
