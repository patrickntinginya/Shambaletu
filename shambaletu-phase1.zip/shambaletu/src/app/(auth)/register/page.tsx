"use client";

import { useState, FormEvent } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import Input from "@/components/ui/Input";
import Select from "@/components/ui/Select";
import Button from "@/components/ui/Button";
import Alert from "@/components/ui/Alert";
import { REGISTERABLE_ROLES, ROLE_LABELS_SW } from "@/lib/roles";
import { TANZANIA_REGIONS } from "@/lib/tanzania-regions";

type FieldErrors = Record<string, string[] | undefined>;

export default function RegisterPage() {
  const router = useRouter();
  const [isLoading, setIsLoading] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);
  const [fieldErrors, setFieldErrors] = useState<FieldErrors>({});

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setFormError(null);
    setFieldErrors({});
    setIsLoading(true);

    const formData = new FormData(event.currentTarget);
    const payload = Object.fromEntries(formData.entries());

    try {
      const res = await fetch("/api/auth/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      const data = await res.json();

      if (!res.ok) {
        setFormError(data.error || "Imeshindwa kujisajili. Jaribu tena.");
        setFieldErrors(data.fieldErrors || {});
        return;
      }

      router.push("/dashboard");
      router.refresh();
    } catch {
      setFormError("Hitilafu ya mtandao. Jaribu tena.");
    } finally {
      setIsLoading(false);
    }
  }

  return (
    <div className="mx-auto flex min-h-screen max-w-md flex-col justify-center px-4 py-10">
      <div className="mb-6 text-center">
        <Link href="/" className="text-xl font-bold text-brand-700">
          ShambaLetu
        </Link>
        <h1 className="mt-3 text-2xl font-bold text-earth-900">Fungua Akaunti</h1>
        <p className="mt-1 text-sm text-earth-800/70">Jiunge na jukwaa la kilimo la Tanzania</p>
      </div>

      {formError && (
        <div className="mb-4">
          <Alert variant="error">{formError}</Alert>
        </div>
      )}

      <form onSubmit={handleSubmit} className="flex flex-col gap-4" noValidate>
        <Input name="name" label="Jina Kamili" placeholder="Mfano: Juma Mwakalinga" required
          error={fieldErrors.name?.[0]} />
        <Input name="email" type="email" label="Barua Pepe" placeholder="wewe@mfano.com" required
          error={fieldErrors.email?.[0]} />
        <Input name="phone" label="Namba ya Simu" placeholder="0712345678" required
          error={fieldErrors.phone?.[0]} />

        <Select
          name="role"
          label="Aina ya Mtumiaji"
          placeholder="Chagua aina yako"
          required
          error={fieldErrors.role?.[0]}
          options={REGISTERABLE_ROLES.map((r) => ({ value: r, label: ROLE_LABELS_SW[r] }))}
        />

        <Select
          name="region"
          label="Mkoa"
          placeholder="Chagua mkoa"
          required
          error={fieldErrors.region?.[0]}
          options={TANZANIA_REGIONS.map((r) => ({ value: r, label: r }))}
        />
        <Input name="district" label="Wilaya" placeholder="Mfano: Kilosa" required
          error={fieldErrors.district?.[0]} />
        <Input name="ward" label="Kata (si lazima)" placeholder="Mfano: Mikumi"
          error={fieldErrors.ward?.[0]} />

        <Input name="password" type="password" label="Nenosiri" required
          hint="Angalau herufi 8, herufi kubwa moja, na namba moja"
          error={fieldErrors.password?.[0]} />
        <Input name="confirmPassword" type="password" label="Thibitisha Nenosiri" required
          error={fieldErrors.confirmPassword?.[0]} />

        <Button type="submit" isLoading={isLoading} fullWidth size="lg" className="mt-2">
          Jisajili
        </Button>
      </form>

      <p className="mt-6 text-center text-sm text-earth-800/70">
        Tayari una akaunti?{" "}
        <Link href="/login" className="font-semibold text-brand-700 hover:underline">
          Ingia hapa
        </Link>
      </p>
    </div>
  );
}
