import { requireRole } from "@/lib/require-role";
import { Role } from "@/lib/roles";
import DashboardShell from "@/components/layout/DashboardShell";
import { Card, PlaceholderCard } from "@/components/ui/Card";
import { prisma } from "@/lib/prisma";

export default async function AdminDashboardPage() {
  const user = await requireRole(Role.ADMIN);

  // Real counts already possible in Phase 1 since the User table exists -
  // everything else (listings, orders, reports) is genuinely not built
  // yet, so it stays as TODO rather than being faked with placeholder
  // numbers.
  const [totalUsers, usersByRole] = await Promise.all([
    prisma.user.count(),
    prisma.user.groupBy({ by: ["role"], _count: { role: true } }),
  ]);

  return (
    <DashboardShell
      userName={user.name}
      role={user.role}
      navItems={[
        { label: "Dashibodi", available: true },
        { label: "Watumiaji", available: false },
        { label: "Bidhaa/Matangazo", available: false },
        { label: "Kategoria", available: false },
        { label: "Ripoti", available: false },
        { label: "Uthibitisho", available: false },
        { label: "Oda", available: false },
        { label: "Takwimu za Jukwaa", available: false },
        { label: "Kumbukumbu (Audit Logs)", available: false },
      ]}
    >
      <h1 className="text-xl font-bold text-earth-900">Dashibodi ya Msimamizi</h1>
      <p className="mt-1 text-sm text-earth-800/70">
        Karibu, {user.name}. Muhtasari wa mfumo wa ShambaLetu.
      </p>

      <div className="mt-6 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
        <Card>
          <p className="text-sm text-earth-800/50">Jumla ya Watumiaji</p>
          <p className="mt-1 text-3xl font-bold text-brand-700">{totalUsers}</p>
        </Card>
        {usersByRole.map((row) => (
          <Card key={row.role}>
            <p className="text-sm text-earth-800/50">{row.role}</p>
            <p className="mt-1 text-3xl font-bold text-earth-900">{row._count.role}</p>
          </Card>
        ))}
      </div>

      <div className="mt-4 grid grid-cols-1 gap-4 lg:grid-cols-2">
        <PlaceholderCard
          title="Usimamizi wa Watumiaji"
          description="Kuzima/kuwezesha akaunti, kubadilisha majukumu, kutafuta watumiaji. Inakuja Phase 2."
        />
        <PlaceholderCard
          title="Usimamizi wa Matangazo"
          description="Kukagua, kuidhinisha au kuondoa matangazo ya bidhaa/mifugo. Inakuja Phase 2."
        />
        <PlaceholderCard
          title="Uthibitisho wa Watumiaji"
          description="Kupitia na kuidhinisha maombi ya uthibitisho wa akaunti. Inakuja baadaye."
        />
        <PlaceholderCard
          title="Ripoti na Malalamiko"
          description="Kushughulikia ripoti za matumizi mabaya ya jukwaa. Inakuja baadaye."
        />
        <PlaceholderCard
          title="Takwimu za Jukwaa"
          description="Grafu za ukuaji, mauzo, na matumizi ya jukwaa. Inakuja baadaye."
        />
        <PlaceholderCard
          title="Kumbukumbu za Mfumo (Audit Logs)"
          description="Kumbukumbu ya vitendo nyeti vya wasimamizi. Inakuja baadaye."
        />
      </div>
    </DashboardShell>
  );
}
