import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { hashPassword } from "@/lib/password";
import { registerSchema } from "@/lib/validation";
import { signSessionToken, sessionCookieOptions, SESSION_COOKIE_NAME } from "@/lib/auth";

export async function POST(request: NextRequest) {
  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "Ombi si sahihi (invalid JSON)." }, { status: 400 });
  }

  const parsed = registerSchema.safeParse(body);
  if (!parsed.success) {
    const fieldErrors = parsed.error.flatten().fieldErrors;
    return NextResponse.json({ error: "Uthibitishaji umeshindwa", fieldErrors }, { status: 422 });
  }

  const { name, email, phone, password, role, region, district, ward } = parsed.data;

  const existing = await prisma.user.findFirst({
    where: { OR: [{ email }, { phone }] },
    select: { id: true, email: true, phone: true },
  });
  if (existing) {
    const field = existing.email === email ? "email" : "phone";
    return NextResponse.json(
      {
        error: "Akaunti tayari ipo",
        fieldErrors: { [field]: ["Tayari imesajiliwa"] },
      },
      { status: 409 }
    );
  }

  const passwordHash = await hashPassword(password);

  const user = await prisma.user.create({
    data: {
      name,
      email,
      phone,
      passwordHash,
      role,
      profile: {
        create: {
          fullName: name,
          phone,
          region,
          district,
          ward: ward || null,
        },
      },
    },
  });

  const token = await signSessionToken({ userId: user.id, role: user.role, name: user.name });

  const response = NextResponse.json(
    {
      user: { id: user.id, name: user.name, email: user.email, role: user.role },
    },
    { status: 201 }
  );
  response.cookies.set(SESSION_COOKIE_NAME, token, sessionCookieOptions());
  return response;
}
