import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { verifyPassword } from "@/lib/password";
import { loginSchema } from "@/lib/validation";
import { signSessionToken, sessionCookieOptions, SESSION_COOKIE_NAME } from "@/lib/auth";

// Generic error message on purpose: never reveal whether the email exists
// or the password was wrong, to avoid account enumeration.
const INVALID_CREDENTIALS_MESSAGE = "Barua pepe au nenosiri si sahihi.";

export async function POST(request: NextRequest) {
  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "Ombi si sahihi (invalid JSON)." }, { status: 400 });
  }

  const parsed = loginSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json(
      { error: "Uthibitishaji umeshindwa", fieldErrors: parsed.error.flatten().fieldErrors },
      { status: 422 }
    );
  }

  const { email, password } = parsed.data;

  const user = await prisma.user.findUnique({ where: { email } });
  if (!user) {
    return NextResponse.json({ error: INVALID_CREDENTIALS_MESSAGE }, { status: 401 });
  }

  if (!user.isActive) {
    return NextResponse.json(
      { error: "Akaunti hii imezimwa. Wasiliana na msimamizi." },
      { status: 403 }
    );
  }

  const validPassword = await verifyPassword(password, user.passwordHash);
  if (!validPassword) {
    return NextResponse.json({ error: INVALID_CREDENTIALS_MESSAGE }, { status: 401 });
  }

  const token = await signSessionToken({ userId: user.id, role: user.role, name: user.name });

  const response = NextResponse.json({
    user: { id: user.id, name: user.name, email: user.email, role: user.role },
  });
  response.cookies.set(SESSION_COOKIE_NAME, token, sessionCookieOptions());
  return response;
}
