import { InputHTMLAttributes, forwardRef } from "react";
import clsx from "@/lib/clsx";

interface InputProps extends InputHTMLAttributes<HTMLInputElement> {
  label: string;
  error?: string;
  hint?: string;
}

const Input = forwardRef<HTMLInputElement, InputProps>(
  ({ label, error, hint, id, className, ...props }, ref) => {
    const inputId = id || props.name;
    return (
      <div className="flex flex-col gap-1.5">
        <label htmlFor={inputId} className="text-sm font-medium text-earth-800">
          {label}
        </label>
        <input
          ref={ref}
          id={inputId}
          className={clsx(
            "w-full rounded-xl2 border px-4 py-3 text-base text-earth-900",
            "focus:outline-none focus:ring-2 focus:ring-brand-500 focus:border-transparent",
            "placeholder:text-earth-800/40",
            error ? "border-red-400" : "border-earth-100",
            className
          )}
          aria-invalid={!!error}
          aria-describedby={error ? `${inputId}-error` : hint ? `${inputId}-hint` : undefined}
          {...props}
        />
        {hint && !error && (
          <p id={`${inputId}-hint`} className="text-xs text-earth-800/60">
            {hint}
          </p>
        )}
        {error && (
          <p id={`${inputId}-error`} className="text-xs font-medium text-red-600">
            {error}
          </p>
        )}
      </div>
    );
  }
);

Input.displayName = "Input";
export default Input;
