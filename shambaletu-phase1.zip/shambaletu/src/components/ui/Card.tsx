import { HTMLAttributes } from "react";
import clsx from "@/lib/clsx";

export function Card({ className, children, ...props }: HTMLAttributes<HTMLDivElement>) {
  return (
    <div
      className={clsx(
        "rounded-xl2 border border-earth-100 bg-white p-5 shadow-sm",
        className
      )}
      {...props}
    >
      {children}
    </div>
  );
}

export function PlaceholderCard({
  title,
  description,
}: {
  title: string;
  description: string;
}) {
  return (
    <Card className="border-dashed bg-earth-50/50">
      <div className="flex items-start justify-between gap-3">
        <div>
          <h3 className="font-semibold text-earth-900">{title}</h3>
          <p className="mt-1 text-sm text-earth-800/70">{description}</p>
        </div>
        <span className="shrink-0 rounded-full bg-harvest-100 px-2.5 py-1 text-xs font-semibold text-harvest-600">
          TODO
        </span>
      </div>
    </Card>
  );
}
