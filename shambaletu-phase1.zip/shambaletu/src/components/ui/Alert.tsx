import { ReactNode } from "react";
import clsx from "@/lib/clsx";

type AlertVariant = "error" | "success" | "info";

const variantClasses: Record<AlertVariant, string> = {
  error: "bg-red-50 text-red-700 border-red-200",
  success: "bg-brand-50 text-brand-700 border-brand-200",
  info: "bg-earth-50 text-earth-800 border-earth-100",
};

export default function Alert({
  variant = "info",
  children,
}: {
  variant?: AlertVariant;
  children: ReactNode;
}) {
  return (
    <div
      role={variant === "error" ? "alert" : "status"}
      className={clsx("rounded-xl2 border px-4 py-3 text-sm", variantClasses[variant])}
    >
      {children}
    </div>
  );
}
