import Link from "next/link";

export default function Navbar() {
  return (
    <header className="sticky top-0 z-30 border-b border-earth-100 bg-white/90 backdrop-blur">
      <nav className="mx-auto flex max-w-6xl items-center justify-between px-4 py-3 sm:px-6">
        <Link href="/" className="flex items-center gap-2">
          <span className="flex h-9 w-9 items-center justify-center rounded-xl2 bg-brand-600 text-lg font-bold text-white">
            S
          </span>
          <span className="text-lg font-bold text-earth-900">ShambaLetu</span>
        </Link>
        <div className="flex items-center gap-2 sm:gap-3">
          <Link
            href="/login"
            className="rounded-xl2 px-3 py-2 text-sm font-semibold text-brand-700 hover:bg-brand-50 sm:px-4"
          >
            Ingia
          </Link>
          <Link
            href="/register"
            className="rounded-xl2 bg-brand-600 px-3 py-2 text-sm font-semibold text-white hover:bg-brand-700 sm:px-4"
          >
            Jisajili
          </Link>
        </div>
      </nav>
    </header>
  );
}
