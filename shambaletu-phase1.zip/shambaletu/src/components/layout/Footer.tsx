export default function Footer() {
  return (
    <footer className="border-t border-earth-100 bg-earth-50/60">
      <div className="mx-auto max-w-6xl px-4 py-8 text-center sm:px-6">
        <p className="text-sm font-semibold text-earth-900">ShambaLetu</p>
        <p className="mt-1 text-xs italic text-earth-800/70">
          Kilimo chetu. Soko letu. Fursa zetu.
        </p>
        <p className="mt-4 text-xs text-earth-800/60">
          © 2026 ShambaLetu. All rights reserved.
        </p>
      </div>
    </footer>
  );
}
