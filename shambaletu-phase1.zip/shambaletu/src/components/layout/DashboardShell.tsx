import { ReactNode } from "react";
import { ROLE_LABELS_SW } from "@/lib/roles";
import { Role } from "@prisma/client";
import LogoutButton from "@/components/layout/LogoutButton";

interface DashboardShellProps {
  userName: string;
  role: Role;
  navItems: { label: string; available: boolean }[];
  children: ReactNode;
}

/**
 * Shared shell for every role dashboard. `navItems` lists the modules that
 * belong on that role's sidebar; `available: false` renders them as
 * clearly-marked upcoming features (per project rule: never fake finished
 * functionality).
 */
export default function DashboardShell({
  userName,
  role,
  navItems,
  children,
}: DashboardShellProps) {
  return (
    <div className="min-h-screen bg-earth-50/40 lg:flex">
      <aside className="border-b border-earth-100 bg-white p-4 lg:w-64 lg:shrink-0 lg:border-b-0 lg:border-r lg:p-6">
        <div className="flex items-center gap-2">
          <span className="flex h-9 w-9 items-center justify-center rounded-xl2 bg-brand-600 text-lg font-bold text-white">
            S
          </span>
          <span className="text-lg font-bold text-earth-900">ShambaLetu</span>
        </div>
        <nav className="mt-6 flex flex-col gap-1">
          {navItems.map((item) => (
            <span
              key={item.label}
              className={
                item.available
                  ? "rounded-xl2 bg-brand-50 px-3 py-2.5 text-sm font-semibold text-brand-700"
                  : "flex items-center justify-between rounded-xl2 px-3 py-2.5 text-sm text-earth-800/50"
              }
            >
              {item.label}
              {!item.available && (
                <span className="rounded-full bg-earth-100 px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wide">
                  Hivi Karibuni
                </span>
              )}
            </span>
          ))}
        </nav>
      </aside>

      <div className="flex-1">
        <header className="flex items-center justify-between border-b border-earth-100 bg-white px-4 py-4 sm:px-6">
          <div>
            <p className="text-sm text-earth-800/60">Karibu,</p>
            <p className="font-semibold text-earth-900">
              {userName}{" "}
              <span className="ml-1 rounded-full bg-harvest-100 px-2 py-0.5 text-xs font-semibold text-harvest-600">
                {ROLE_LABELS_SW[role]}
              </span>
            </p>
          </div>
          <LogoutButton />
        </header>
        <main className="p-4 sm:p-6">{children}</main>
      </div>
    </div>
  );
}
