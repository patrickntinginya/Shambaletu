import { Card } from "@/components/ui/Card";

interface ProfileSummaryCardProps {
  fullName: string;
  email: string;
  phone: string | null;
  region: string | null;
  district: string | null;
  ward: string | null;
  bio: string | null;
}

export default function ProfileSummaryCard({
  fullName,
  email,
  phone,
  region,
  district,
  ward,
  bio,
}: ProfileSummaryCardProps) {
  const location = [ward, district, region].filter(Boolean).join(", ") || "Haijawekwa";

  return (
    <Card>
      <h3 className="font-semibold text-earth-900">Wasifu Wako</h3>
      <dl className="mt-3 grid grid-cols-1 gap-3 text-sm sm:grid-cols-2">
        <div>
          <dt className="text-earth-800/50">Jina</dt>
          <dd className="font-medium text-earth-900">{fullName}</dd>
        </div>
        <div>
          <dt className="text-earth-800/50">Barua Pepe</dt>
          <dd className="font-medium text-earth-900">{email}</dd>
        </div>
        <div>
          <dt className="text-earth-800/50">Simu</dt>
          <dd className="font-medium text-earth-900">{phone || "Haijawekwa"}</dd>
        </div>
        <div>
          <dt className="text-earth-800/50">Mahali</dt>
          <dd className="font-medium text-earth-900">{location}</dd>
        </div>
      </dl>
      {bio && <p className="mt-4 border-t border-earth-100 pt-3 text-sm text-earth-800/70">{bio}</p>}
    </Card>
  );
}
