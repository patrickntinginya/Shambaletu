import { NextRequest, NextResponse } from "next/server";
import { jwtVerify } from "jose";
import { SESSION_COOKIE_NAME } from "@/lib/auth";
import {
  DASHBOARD_PATH_ROLE_MAP,
  ROLE_DASHBOARD_PATH_MAP,
  type RoleName,
} from "@/lib/role-paths";

// NOTE: Middleware runs on the Edge Runtime, so it verifies the JWT
// directly with `jose` rather than importing the Prisma-backed helpers
// in src/lib/current-user.ts (Prisma Client is not Edge-compatible).
// This is intentionally the ONLY place route protection is enforced at
// the network edge; every dashboard/admin page also re-checks the role
// server-side via getCurrentUser() as defense in depth.

async function verifyToken(token: string) {
  try {
    const secret = new TextEncoder().encode(process.env.AUTH_SECRET);
    const { payload } = await jwtVerify(token, secret);
    return payload as { userId: string; role: RoleName; name: string };
  } catch {
    return null;
  }
}

export async function middleware(request: NextRequest) {
  const { pathname } = request.nextUrl;

  const isProtectedRoute =
    pathname.startsWith("/dashboard") || pathname.startsWith("/admin");

  if (!isProtectedRoute) {
    return NextResponse.next();
  }

  const token = request.cookies.get(SESSION_COOKIE_NAME)?.value;
  const session = token ? await verifyToken(token) : null;

  if (!session) {
    const loginUrl = new URL("/login", request.url);
    loginUrl.searchParams.set("next", pathname);
    return NextResponse.redirect(loginUrl);
  }

  // Generic /dashboard root: send the user to their role-specific dashboard.
  if (pathname === "/dashboard") {
    return NextResponse.redirect(
      new URL(ROLE_DASHBOARD_PATH_MAP[session.role], request.url)
    );
  }

  // Enforce that a user can only access the dashboard matching their own
  // role (e.g. a BUYER cannot open /dashboard/farmer by guessing the URL).
  const matchedPrefix = Object.keys(DASHBOARD_PATH_ROLE_MAP).find((prefix) =>
    pathname.startsWith(prefix)
  );
  if (matchedPrefix && DASHBOARD_PATH_ROLE_MAP[matchedPrefix] !== session.role) {
    return NextResponse.redirect(
      new URL(ROLE_DASHBOARD_PATH_MAP[session.role], request.url)
    );
  }

  // Admin area requires the ADMIN role specifically. Compared as a plain
  // string literal (not Role.ADMIN) so this file never needs a runtime
  // import from @prisma/client, which is not Edge Runtime compatible.
  if (pathname.startsWith("/admin") && session.role !== "ADMIN") {
    return NextResponse.redirect(
      new URL(ROLE_DASHBOARD_PATH_MAP[session.role], request.url)
    );
  }

  return NextResponse.next();
}

export const config = {
  matcher: ["/dashboard/:path*", "/admin/:path*"],
};
