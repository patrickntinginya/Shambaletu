import "server-only";
import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/current-user";
import { Role, ROLE_DASHBOARD_PATH } from "@/lib/roles";

/**
 * Ensures the current request belongs to a logged-in user with the given
 * role. Redirects to /login if not authenticated, or to that user's own
 * dashboard if they are logged in as a different role. This duplicates
 * part of what middleware.ts already does - that's intentional defense in
 * depth, since middleware can't see fresh database state (e.g. a role
 * change or deactivation) the way this Prisma-backed check can.
 */
export async function requireRole(expectedRole: Role) {
  const user = await getCurrentUser();

  if (!user) {
    redirect("/login");
  }

  if (user.role !== expectedRole) {
    redirect(ROLE_DASHBOARD_PATH[user.role]);
  }

  return user;
}
