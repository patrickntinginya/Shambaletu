import { z } from "zod";
import { Role } from "@prisma/client";

// Basic East African phone number check: optional +255 / 0 prefix followed
// by 9 digits. Deliberately permissive at this stage - can be tightened
// once SMS verification (Phase 2+) is implemented.
const phoneRegex = /^(\+?255|0)[67]\d{8}$/;

export const registerSchema = z
  .object({
    name: z
      .string()
      .trim()
      .min(2, "Jina ni fupi mno")
      .max(100, "Jina ni refu mno"),
    email: z.string().trim().toLowerCase().email("Barua pepe si sahihi"),
    phone: z
      .string()
      .trim()
      .regex(phoneRegex, "Namba ya simu si sahihi (mfano: 0712345678)"),
    password: z
      .string()
      .min(8, "Nenosiri linahitaji angalau herufi 8")
      .max(72, "Nenosiri ni refu mno")
      .regex(/[A-Z]/, "Nenosiri linahitaji herufi kubwa moja")
      .regex(/[0-9]/, "Nenosiri linahitaji namba moja"),
    confirmPassword: z.string(),
    role: z.nativeEnum(Role, { errorMap: () => ({ message: "Chagua aina ya mtumiaji" }) }),
    region: z.string().trim().min(2, "Chagua mkoa"),
    district: z.string().trim().min(2, "Chagua wilaya"),
    ward: z.string().trim().optional().or(z.literal("")),
  })
  .refine((data) => data.password === data.confirmPassword, {
    message: "Manenosiri hayafanani",
    path: ["confirmPassword"],
  })
  .refine((data) => data.role !== Role.ADMIN, {
    message: "Huwezi kujisajili kama Msimamizi",
    path: ["role"],
  });

export type RegisterInput = z.infer<typeof registerSchema>;

export const loginSchema = z.object({
  email: z.string().trim().toLowerCase().email("Barua pepe si sahihi"),
  password: z.string().min(1, "Nenosiri linahitajika"),
});

export type LoginInput = z.infer<typeof loginSchema>;
