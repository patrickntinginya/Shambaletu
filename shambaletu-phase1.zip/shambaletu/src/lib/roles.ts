import { Role } from "@prisma/client";
import { ROLE_DASHBOARD_PATH_MAP, DASHBOARD_PATH_ROLE_MAP } from "@/lib/role-paths";

export { Role };

/**
 * Human-readable Swahili labels for each role. Kept in one place so
 * future localization (English toggle) only needs to change this map,
 * not every page that displays a role.
 */
export const ROLE_LABELS_SW: Record<Role, string> = {
  FARMER: "Mkulima",
  LIVESTOCK_KEEPER: "Mfugaji",
  BUYER: "Mnunuzi",
  AGRICULTURAL_BUSINESS: "Biashara ya Kilimo",
  TRANSPORTER: "Msafirishaji",
  SERVICE_PROVIDER: "Mtoa Huduma",
  ADMIN: "Msimamizi",
};

export const ROLE_LABELS_EN: Record<Role, string> = {
  FARMER: "Farmer",
  LIVESTOCK_KEEPER: "Livestock Keeper",
  BUYER: "Buyer",
  AGRICULTURAL_BUSINESS: "Agricultural Business",
  TRANSPORTER: "Transporter",
  SERVICE_PROVIDER: "Service Provider",
  ADMIN: "Admin",
};

/**
 * Where each role lands after login. Re-exported (and re-typed against
 * Prisma's Role enum) from the edge-safe src/lib/role-paths.ts, which is
 * the single source of truth for the actual path strings.
 */
export const ROLE_DASHBOARD_PATH = ROLE_DASHBOARD_PATH_MAP as Record<Role, string>;

/** Roles selectable at registration (ADMIN is provisioned separately). */
export const REGISTERABLE_ROLES = Object.values(Role).filter(
  (r) => r !== Role.ADMIN
) as Exclude<Role, "ADMIN">[];

/** Maps each dashboard path prefix to the role allowed to access it. */
export const DASHBOARD_PATH_ROLE = DASHBOARD_PATH_ROLE_MAP as Record<string, Role>;
