/**
 * Regions of Tanzania (Mainland + Zanzibar), used for the registration
 * form's region select. District/ward are free-text in Phase 1; a proper
 * normalized Location table (region -> district -> ward) is planned for
 * a later phase once the marketplace module needs structured filtering.
 */
export const TANZANIA_REGIONS = [
  "Arusha",
  "Dar es Salaam",
  "Dodoma",
  "Geita",
  "Iringa",
  "Kagera",
  "Katavi",
  "Kigoma",
  "Kilimanjaro",
  "Lindi",
  "Manyara",
  "Mara",
  "Mbeya",
  "Morogoro",
  "Mtwara",
  "Mwanza",
  "Njombe",
  "Pemba Kaskazini",
  "Pemba Kusini",
  "Pwani",
  "Rukwa",
  "Ruvuma",
  "Shinyanga",
  "Simiyu",
  "Singida",
  "Songwe",
  "Tabora",
  "Tanga",
  "Unguja Kaskazini",
  "Unguja Kusini",
  "Unguja Mjini Magharibi",
] as const;
