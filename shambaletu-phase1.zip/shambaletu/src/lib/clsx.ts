type ClassValue = string | number | false | null | undefined;

/**
 * Tiny "classnames" utility - joins truthy class name fragments with a
 * space. Kept in-house to avoid pulling in an extra dependency for
 * something this small.
 */
export default function clsx(...values: ClassValue[]): string {
  return values.filter(Boolean).join(" ");
}
