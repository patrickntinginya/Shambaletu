/**
 * Role-to-dashboard-path mapping using plain string literals only.
 *
 * This file must NEVER import from "@prisma/client" (directly or
 * transitively), because src/middleware.ts imports it and runs on the
 * Next.js Edge Runtime, where the Prisma Client query engine is not
 * supported. src/lib/roles.ts re-exports these same maps for use in
 * regular server code, where importing Prisma is fine.
 */
export const ROLE_DASHBOARD_PATH_MAP = {
  FARMER: "/dashboard/farmer",
  LIVESTOCK_KEEPER: "/dashboard/livestock",
  BUYER: "/dashboard/buyer",
  AGRICULTURAL_BUSINESS: "/dashboard/business",
  TRANSPORTER: "/dashboard/transporter",
  SERVICE_PROVIDER: "/dashboard/service-provider",
  ADMIN: "/admin/dashboard",
} as const;

export type RoleName = keyof typeof ROLE_DASHBOARD_PATH_MAP;

export const DASHBOARD_PATH_ROLE_MAP: Record<string, RoleName> = Object.entries(
  ROLE_DASHBOARD_PATH_MAP
).reduce((acc, [role, path]) => {
  acc[path] = role as RoleName;
  return acc;
}, {} as Record<string, RoleName>);
