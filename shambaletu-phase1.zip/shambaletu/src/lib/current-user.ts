import "server-only";
import { prisma } from "@/lib/prisma";
import { getSession } from "@/lib/auth";

/**
 * Returns the full, fresh user record (with profile) for the currently
 * authenticated session, or null if not logged in / user no longer exists.
 *
 * Always re-reads from the database rather than trusting the JWT payload
 * alone, so a deactivated account or role change takes effect immediately
 * rather than waiting for the token to expire.
 */
export async function getCurrentUser() {
  const session = await getSession();
  if (!session) return null;

  const user = await prisma.user.findUnique({
    where: { id: session.userId },
    include: { profile: true },
  });

  if (!user || !user.isActive) return null;

  // Never leak the password hash to any caller, ever.
  const { passwordHash: _passwordHash, ...safeUser } = user;
  return safeUser;
}
