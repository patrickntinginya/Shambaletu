import { SignJWT, jwtVerify } from "jose";
import { cookies } from "next/headers";
import type { Role } from "@prisma/client";

export const SESSION_COOKIE_NAME = "shambaletu_session";
const SESSION_DURATION_SECONDS = 60 * 60 * 24 * 7; // 7 days

export interface SessionPayload {
  userId: string;
  role: Role;
  name: string;
  [key: string]: unknown;
}

function getSecretKey(): Uint8Array {
  const secret = process.env.AUTH_SECRET;
  if (!secret || secret.length < 16) {
    // Fail loudly rather than silently signing tokens with a weak/missing
    // secret - this is a security-critical configuration value.
    throw new Error(
      "AUTH_SECRET is missing or too short. Set a strong random value in .env (see .env.example)."
    );
  }
  return new TextEncoder().encode(secret);
}

/**
 * Sign a session JWT for the given payload. Used right after successful
 * registration or login.
 */
export async function signSessionToken(payload: SessionPayload): Promise<string> {
  return new SignJWT(payload)
    .setProtectedHeader({ alg: "HS256" })
    .setIssuedAt()
    .setExpirationTime(`${SESSION_DURATION_SECONDS}s`)
    .sign(getSecretKey());
}

/**
 * Verify and decode a session JWT. Returns null if invalid/expired instead
 * of throwing, so callers can treat it as "not logged in".
 */
export async function verifySessionToken(
  token: string
): Promise<SessionPayload | null> {
  try {
    const { payload } = await jwtVerify(token, getSecretKey());
    return payload as unknown as SessionPayload;
  } catch {
    return null;
  }
}

/**
 * Cookie options shared between setting and clearing the session cookie.
 * `secure` is enabled outside local development so the cookie is never
 * sent over plain HTTP in production.
 */
export function sessionCookieOptions() {
  return {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax" as const,
    path: "/",
    maxAge: SESSION_DURATION_SECONDS,
  };
}

/**
 * Server Component / Route Handler helper: read and verify the session
 * cookie for the current request. Returns null if not logged in.
 */
export async function getSession(): Promise<SessionPayload | null> {
  const token = cookies().get(SESSION_COOKIE_NAME)?.value;
  if (!token) return null;
  return verifySessionToken(token);
}
