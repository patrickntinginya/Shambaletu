/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  images: {
    // TODO(Phase 2+): add remote patterns for the cloud image storage
    // provider once it is selected (e.g. Cloudinary, S3, Supabase Storage).
    remotePatterns: [],
  },
};

export default nextConfig;
