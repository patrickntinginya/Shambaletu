# ShambaLetu

**Kilimo chetu. Soko letu. Fursa zetu.**

A digital agricultural marketplace and services platform for Tanzania, connecting
farmers, livestock keepers, buyers, agricultural businesses, transporters, and
agricultural service providers.

This repository currently contains **Phase 1 only**: project setup, database
foundation, authentication, roles, and per-role dashboard shells. The
marketplace, messaging, orders, and other modules described in the full
product spec are intentionally **not** built yet (see "Future modules"
below) — they are marked as TODO in the UI rather than faked.

---

## ⚠️ Important: this code has not been run or compiled

This project was written in an environment with **no network access**, so
`npm install`, `next build`, `tsc`, `next lint`, and `prisma generate` were
**never actually executed**. The code was written carefully and reviewed by
hand, but it has **not been verified to compile or run**.

**Before you trust this as working software, you must run it yourself and
fix anything that comes up.** Realistic things to double check:

- Exact Next.js 14 API route / App Router syntax (types on `params`, cookie
  API signatures — `cookies()` becoming async in some Next 14 patch/App
  Router combinations is a known area to double check against whatever
  exact `next` version `npm install` resolves).
- Prisma Client generated types (`Role` enum import, `groupBy` shape).
- Tailwind class names / config actually compiling without typos.
- `jose` and `bcryptjs` API usage.

Please run the typecheck/build/test commands below and report back any
errors — that's the fastest way to get this to a verified working state.

---

## Tech stack

| Layer          | Choice                                   |
|----------------|-------------------------------------------|
| Frontend       | Next.js 14 (App Router), TypeScript, Tailwind CSS |
| Backend        | Next.js Route Handlers (REST-style API)   |
| Database       | PostgreSQL                                |
| ORM            | Prisma                                    |
| Auth           | Custom JWT session (httpOnly cookie, signed with `jose`) + `bcryptjs` password hashing |
| Validation     | Zod                                       |

No external auth-as-a-service, no ORM other than Prisma, no UI kit — kept
deliberately minimal for Phase 1.

---

## Project structure

```
shambaletu/
├── prisma/
│   ├── schema.prisma        # User, Profile, Farm, LivestockProfile, Role enum
│   └── seed.ts               # Demo accounts (one per role)
├── src/
│   ├── app/
│   │   ├── (auth)/login, (auth)/register    # Public auth pages
│   │   ├── api/auth/{register,login,logout,me}/route.ts
│   │   ├── dashboard/{farmer,livestock,buyer,business,transporter,service-provider}
│   │   ├── admin/dashboard
│   │   ├── page.tsx           # Public homepage
│   │   └── layout.tsx
│   ├── components/
│   │   ├── ui/                # Button, Input, Select, Card, Alert
│   │   ├── layout/             # Navbar, Footer, DashboardShell, LogoutButton
│   │   └── dashboard/           # ProfileSummaryCard
│   ├── lib/
│   │   ├── prisma.ts, auth.ts, password.ts, validation.ts
│   │   ├── roles.ts, current-user.ts, require-role.ts
│   │   └── tanzania-regions.ts
│   └── middleware.ts           # Edge route protection
└── tests/                      # Vitest unit tests
```

### Future modules (not implemented, folders not yet created)

marketplace (products/categories/images), buyer requests ("Nina Hitaji") +
smart matching, messaging, reviews/trust score, verification, orders,
delivery/transport, payments, notifications, admin moderation tools,
price intelligence, analytics, AI assistant. These are listed here so the
intended shape of the system is documented even before code exists for them.

---

## Setup instructions

### 1. Prerequisites

- Node.js ≥ 18.18
- A running PostgreSQL instance (local, Docker, or hosted)

### 2. Install dependencies

```bash
npm install
```

### 3. Configure environment variables

```bash
cp .env.example .env
```

Then edit `.env`:

- `DATABASE_URL` — your PostgreSQL connection string
- `AUTH_SECRET` — generate one with `openssl rand -base64 48`

### 4. Set up the database

```bash
npx prisma migrate dev --name init
npm run seed
```

This creates the tables and seeds one demo account per role (see below).

### 5. Run the app

```bash
npm run dev
```

Visit `http://localhost:3000`.

---

## Verification commands (run these yourself)

```bash
npm run typecheck   # tsc --noEmit
npm run lint        # next lint
npm run build       # next build
npm test            # vitest run
```

None of these have been run in this environment. Please run them and share
any errors so they can be fixed.

---

## Demo / test accounts

All seeded accounts use the password: **`Password123!`**

| Role                   | Email                          |
|------------------------|----------------------------------|
| Farmer                 | farmer@shambaletu.co.tz         |
| Livestock Keeper       | livestock@shambaletu.co.tz      |
| Buyer                  | buyer@shambaletu.co.tz          |
| Agricultural Business  | business@shambaletu.co.tz       |
| Transporter            | transporter@shambaletu.co.tz    |
| Service Provider       | vet@shambaletu.co.tz            |
| Admin                  | admin@shambaletu.co.tz          |

---

## Authentication flow

1. `POST /api/auth/register` — validates input with Zod, checks for
   existing email/phone, hashes the password with bcrypt (12 rounds),
   creates `User` + `Profile`, signs a JWT, sets it as an httpOnly cookie.
2. `POST /api/auth/login` — validates credentials, verifies the password
   hash, signs a JWT, sets the cookie. Returns a generic error message on
   failure (does not reveal whether the email exists).
3. `POST /api/auth/logout` — clears the cookie.
4. `GET /api/auth/me` — returns the current user (or `null`) based on the
   cookie, for client components that need session info.
5. `src/middleware.ts` — runs on the Edge Runtime, verifies the JWT on
   every request to `/dashboard/*` and `/admin/*`, redirects unauthenticated
   users to `/login`, and redirects a logged-in user away from a dashboard
   that doesn't match their own role.
6. Each dashboard page **also** calls `requireRole()` server-side (which
   re-reads the user from the database) as defense in depth, since
   middleware can't see a role change or account deactivation the moment
   it happens.

Passwords are never stored or logged in plain text. The session JWT payload
contains only `userId`, `role`, and `name` — never the password hash.

---

## Security notes (Phase 1 scope)

- Server-side Zod validation on every mutating API route (not just
  client-side).
- `passwordHash` is stripped from every object returned to the client
  (see `getCurrentUser()`).
- Role checks happen at two layers: edge middleware + server component.
- Exact farm/home coordinates are never collected in Phase 1 — only
  `approximateLocation` (free text) is stored on `Farm`, per the
  requirement not to expose private coordinates publicly.
- Rate limiting is **not implemented** in Phase 1 (no infrastructure for
  it yet) — flagged here as a known gap for Phase 2, not silently skipped.
- File upload validation, audit logging, and full authorization checks
  beyond "does this role match" are also Phase 2+ — there is no file
  upload or admin-mutation functionality yet to secure.

---

## Known remaining issues / honesty notes

- **Not run or compiled** — see warning at the top of this file.
- Next.js 14's exact `cookies()`/Route Handler typing can shift between
  minor versions; double-check against the installed version.
- District/ward are free-text fields in Phase 1, not a normalized
  `Location` table — intentional, to avoid over-engineering before the
  marketplace module needs structured filtering.
- No email/SMS is actually sent for verification — the schema and UI
  copy reference future verification, but no provider is integrated.
- Admin dashboard shows real user counts (the `User` table exists and is
  queried live) but every other admin metric is a TODO placeholder, not a
  fake number.

---

## License / attribution

© 2026 ShambaLetu. All rights reserved. This project uses open-source
third-party libraries (Next.js, Prisma, Tailwind CSS, Zod, jose, bcryptjs,
etc.) under their respective licenses — ShambaLetu claims no ownership
over them.
